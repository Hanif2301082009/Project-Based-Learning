package com.teknologiinformasi.auth.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;


import com.teknologiinformasi.auth.model.User;
import com.teknologiinformasi.auth.repository.UserRepository;
import com.teknologiinformasi.auth.security.JwtTokenProvider;


import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/auth")
public class AuthController {


   @Autowired
   private UserRepository userRepository;


   @Autowired
   private JwtTokenProvider tokenProvider;


   @Autowired
   private PasswordEncoder passwordEncoder;


   @PostMapping("/register")
   public String register(@RequestBody User user) {
       user.setPassword(passwordEncoder.encode(user.getPassword()));
       userRepository.save(user);
       return "User registered successfully";
   }


   @PostMapping("/login")
   public Map<String, String> login(@RequestBody User loginRequest) {
       User user = userRepository.findByEmail(loginRequest.getEmail())
               .orElseThrow(() -> new RuntimeException("User not found"));


       if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPassword())) {
           throw new RuntimeException("Invalid credentials");
       }


       String token = tokenProvider.generateToken(user.getEmail());


       Map<String, String> response = new HashMap<>();
       response.put("token", token);
       return response;
   }
}

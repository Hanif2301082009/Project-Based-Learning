package com.teknologiinformasi.auth.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


import java.security.Key;
import java.util.Date;


@Component
public class JwtTokenProvider {


   @Value("${jwt.secret}")
   private String jwtSecret;


   @Value("${jwt.expirationMs}")
   private int jwtExpirationMs;


   public String generateToken(String username) {
       Date now = new Date();
       Date expiryDate = new Date(now.getTime() + jwtExpirationMs);


       Key key = Keys.hmacShaKeyFor(jwtSecret.getBytes());


       return Jwts.builder()
               .setSubject(username)
               .setIssuedAt(now)
               .setExpiration(expiryDate)
               .signWith(key)
               .compact();
   }


   public String getUsernameFromJWT(String token) {
       return Jwts.parserBuilder()
               .setSigningKey(jwtSecret.getBytes())
               .build()
               .parseClaimsJws(token)
               .getBody()
               .getSubject();
   }
}
